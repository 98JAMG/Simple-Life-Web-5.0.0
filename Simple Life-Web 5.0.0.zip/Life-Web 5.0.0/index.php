<?php
    $userIP = $_SERVER['REMOTE_ADDR'];
    session_start();
    if (!isset($_SESSION['loginuser'])) {
        header("location:login");
    }

    include "database.php";

    $accion = (isset($_GET['accion'])) ? $_GET['accion'] : "";
    $victim = (isset($_GET['previousVictim'])) ? $_GET['previousVictim'] : "";

    $countTotalVehiclesSQL = $connectionSQLi->query("SELECT id FROM vehicles");
    $countTotalVehicles = $countTotalVehiclesSQL->num_rows;
    $countVehiclesAirSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Air'");
    $countVehiclesAir = $countVehiclesAirSQL->num_rows;
    $countVehiclesCarSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Car'");
    $countVehiclesCar = $countVehiclesCarSQL->num_rows;
    $countVehiclesShipSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Ship'");
    $countVehiclesShip = $countVehiclesShipSQL->num_rows;
    $countVehiclesOtherSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type!='Air' AND type!='Car' AND type!='Ship'");
    $countVehiclesOther = $countVehiclesOtherSQL->num_rows;
    $countVehiclesCivSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE side='civ'");
    $countVehiclesCiv = $countVehiclesCivSQL->num_rows;
    $countVehiclesCopSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE side='cop'");
    $countVehiclesCop = $countVehiclesCopSQL->num_rows;
    $countVehiclesMedSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE side='med'");
    $countVehiclesMed = $countVehiclesMedSQL->num_rows;
    $countVehiclesCivAirSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Air' AND side='civ'");
    $countVehiclesCivAir = $countVehiclesCivAirSQL->num_rows;
    $countVehiclesCivCarSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Car' AND side='civ'");
    $countVehiclesCivCar = $countVehiclesCivCarSQL->num_rows;
    $countVehiclesCivShipSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Ship' AND side='civ'");
    $countVehiclesCivShip = $countVehiclesCivShipSQL->num_rows;
    $countVehiclesCivOtherSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type!='Air' AND type!='Car' AND type!='Ship' AND side='civ'");
    $countVehiclesCivOther = $countVehiclesCivOtherSQL->num_rows;
    $countVehiclesCopAirSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Air' AND side='cop'");
    $countVehiclesCopAir = $countVehiclesCopAirSQL->num_rows;
    $countVehiclesCopCarSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Car' AND side='cop'");
    $countVehiclesCopCar = $countVehiclesCopCarSQL->num_rows;
    $countVehiclesCopShipSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Ship' AND side='cop'");
    $countVehiclesCopShip = $countVehiclesCopShipSQL->num_rows;
    $countVehiclesCopOtherSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type!='Air' AND type!='Car' AND type!='Ship' AND side='cop'");
    $countVehiclesCopOther = $countVehiclesCopOtherSQL->num_rows;
    $countVehiclesMedAirSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Air' AND side='med'");
    $countVehiclesMedAir = $countVehiclesMedAirSQL->num_rows;
    $countVehiclesMedCarSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Car' AND side='med'");
    $countVehiclesMedCar = $countVehiclesMedCarSQL->num_rows;
    $countVehiclesMedShipSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type='Ship' AND side='med'");
    $countVehiclesMedShip = $countVehiclesMedShipSQL->num_rows;
    $countVehiclesMedOtherSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE type!='Air' AND type!='Car' AND type!='Ship' AND side='med'");
    $countVehiclesMedOther = $countVehiclesMedOtherSQL->num_rows;
    $countTotalVehiclesBlacklistSQL = $connectionSQLi->query("SELECT blacklist FROM vehicles WHERE blacklist=1");
    $countTotalVehiclesBlacklist = $countTotalVehiclesBlacklistSQL->num_rows;

    $countTotalPlayersSQL = $connectionSQLi->query("SELECT uid FROM players");
    $countTotalPlayers = $countTotalPlayersSQL->num_rows;
    $countCopPlayersSQL = $connectionSQLi->query("SELECT uid FROM players WHERE coplevel!='0'");
    $countCopPlayers = $countCopPlayersSQL->num_rows;
    $countMedPlayersSQL = $connectionSQLi->query("SELECT uid FROM players WHERE mediclevel!='0'");
    $countMedPlayers = $countMedPlayersSQL->num_rows;
    $countCivPlayersSQL = $connectionSQLi->query("SELECT uid FROM players WHERE mediclevel='0' AND coplevel='0'");
    $countCivPlayers = $countCivPlayersSQL->num_rows;
    $countAdminPlayersSQL = $connectionSQLi->query("SELECT uid FROM players WHERE adminlevel!='0'");
    $countAdminPlayers = $countAdminPlayersSQL->num_rows;
    $countDonnorPlayersSQL = $connectionSQLi->query("SELECT uid FROM players WHERE donorlevel!='0'");
    $countDonnorlayers = $countDonnorPlayersSQL->num_rows;

    $countTotalHousesSQL = $connectionSQLi->query("SELECT id FROM houses");
    $countTotalHouses = $countTotalHousesSQL->num_rows;
    $countTotalGarageSQL = $connectionSQLi->query("SELECT id FROM houses WHERE garage!='0'");
    $countTotalGarage = $countTotalGarageSQL->num_rows;
    
    $countTotalContainersSQL = $connectionSQLi->query("SELECT id FROM containers");
    $countTotalContainers = $countTotalContainersSQL->num_rows;

    $countTotalGangsSQL = $connectionSQLi->query("SELECT id FROM gangs");
    $countTotalGangs = $countTotalGangsSQL->num_rows;

    $countTotalWantedSQL = $connectionSQLi->query("SELECT wantedID FROM wanted");
    $countTotalWanted = $countTotalWantedSQL->num_rows;
    $countTotalMostWantedSQL = $connectionSQLi->query("SELECT wantedID FROM wanted WHERE active='1'");
    $countTotalMostWanted = $countTotalMostWantedSQL->num_rows;

    $countArrestedSQL = $connectionSQLi->query("SELECT uid FROM players WHERE arrested!='0'");
    $countArrested = $countArrestedSQL->num_rows;
    $countBannedSQL = $connectionSQLi->query("SELECT uid FROM players WHERE blacklist!='0'");
    $countBanned = $countBannedSQL->num_rows;

    $sumBountySQL = "SELECT wantedBounty FROM wanted";
    $sumBountycount = mysqli_query($connectionSQLi,$sumBountySQL);
    $sumBounty = 0;
    while ($rowBounty = mysqli_fetch_assoc($sumBountycount)) {
        $sumBounty += $rowBounty['wantedBounty'];
    }
    $sumBountyVariable = $sumBounty;
    $sumBountyFormat = number_format($sumBountyVariable, '0', ',', '.');

    $sumPlayerTotalCashSQL = "SELECT cash FROM players";
    $sumPlayerTotalCashcount = mysqli_query($connectionSQLi,$sumPlayerTotalCashSQL);
    $PlayerTotalCash = 0;
    while ($rowPlayerCash = mysqli_fetch_assoc($sumPlayerTotalCashcount)) {
        $PlayerTotalCash += $rowPlayerCash['cash'];
    }
    $PlayerTotalCashVariable = $PlayerTotalCash;
    $PlayerTotalCashFormat = number_format($PlayerTotalCashVariable, '0', ',', '.');

    $sumPlayerTotalBankaccSQL = "SELECT bankacc FROM players";
    $sumPlayerTotalBankacccount = mysqli_query($connectionSQLi,$sumPlayerTotalBankaccSQL);
    $PlayerTotalBankacc = 0;
    while ($rowPlayerBankacc = mysqli_fetch_assoc($sumPlayerTotalBankacccount)) {
        $PlayerTotalBankacc += $rowPlayerBankacc['bankacc'];
    }
    $PlayerTotalBankaccVariable = $PlayerTotalBankacc;
    $PlayerTotalBankaccFormat = number_format($PlayerTotalBankaccVariable, '0', ',', '.');

    $sumGangTotalBankaccSQL = "SELECT bank FROM gangs";
    $sumGangTotalBankacccount=mysqli_query($connectionSQLi,$sumGangTotalBankaccSQL);
    $GangTotalBankacc = 0;
    while ($rowGangBankacc = mysqli_fetch_assoc($sumGangTotalBankacccount)) {
        $GangTotalBankacc += $rowGangBankacc['bank'];
    }
    $GangTotalBankaccVariable = $GangTotalBankacc;
    $GangTotalBankaccFormat = number_format($GangTotalBankaccVariable, '0', ',', '.');

    $vehiclesTotalHistorySQL = $connectionSQLi->query("SELECT MAX(id) AS maxvehiclehistory FROM vehicles");
    if ($vehiclesTotalHistorySQL->num_rows > 0) {
        $maxVehicleRow = $vehiclesTotalHistorySQL->fetch_assoc();
        $vehiclesTotalHistory = $maxVehicleRow['maxvehiclehistory'];
    }
    $playersTotalHistorySQL = $connectionSQLi->query("SELECT MAX(uid) AS maxplayershistory FROM players");
    if ($playersTotalHistorySQL->num_rows > 0) {
        $maxPlayersRow = $playersTotalHistorySQL->fetch_assoc();
        $playersTotalHistory = $maxPlayersRow['maxplayershistory'];
    }
    $housesTotalHistorySQL = $connectionSQLi->query("SELECT MAX(id) AS maxhouseshistory FROM houses");
    if ($housesTotalHistorySQL->num_rows > 0) {
        $maxHousesRow = $housesTotalHistorySQL->fetch_assoc();
        $housesTotalHistory = $maxHousesRow['maxhouseshistory'];
    }
    $gangsTotalHistorySQL = $connectionSQLi->query("SELECT MAX(id) AS maxgangshistory FROM gangs");
    if ($gangsTotalHistorySQL->num_rows > 0) {
        $maxGangsRow = $gangsTotalHistorySQL->fetch_assoc();
        $gangsTotalHistory = $maxGangsRow['maxgangshistory'];
    }

    $playerMaxCashSQL = $connectionSQLi->query("SELECT MAX(cash) AS maxplayercash FROM players");
    $playerMaxBankaccSQL = $connectionSQLi->query("SELECT MAX(bankacc) AS maxplayerbankacc FROM players");
    if ($playerMaxCashSQL->num_rows > 0 && $playerMaxBankaccSQL->num_rows > 0) {
        $maxCashRow = $playerMaxCashSQL->fetch_assoc();
        $playerMaxCash = $maxCashRow['maxplayercash'];
        $maxBankaccRow = $playerMaxBankaccSQL->fetch_assoc();
        $playerMaxBankacc = $maxBankaccRow['maxplayerbankacc'];
        $maxCashPlayerSQL = $connectionSQLi->query("SELECT cash,name FROM players WHERE cash='$playerMaxCash'");
        $maxCashPlayerRow = $maxCashPlayerSQL->fetch_assoc();
        $maxCashPlayer = $maxCashPlayerRow['name'];
        $maxBankaccPlayerSQL = $connectionSQLi->query("SELECT bankacc,name FROM players WHERE bankacc='$playerMaxBankacc'");
        $maxBankaccPlayerRow = $maxBankaccPlayerSQL->fetch_assoc();
        $maxBankaccPlayer = $maxBankaccPlayerRow['name'];
    } else {
        $maxBankaccPlayer = "";
        $maxCashPlayer = "";
    }

    $playerMostWantedSQL = $connectionSQLi->query("SELECT MAX(wantedBounty) AS maxbounty FROM wanted");
    if ($playerMostWantedSQL->num_rows > 0) {
        $playerMostWantedRow = $playerMostWantedSQL->fetch_assoc();
        $playerMostWantedBounty = $playerMostWantedRow['maxbounty'];

        $mostWantedSQL = $connectionSQLi->query("SELECT wantedName FROM wanted WHERE wantedBounty='$playerMostWantedBounty'");
        $mostWantedRow = $mostWantedSQL->fetch_assoc();
        $mostWanted = $mostWantedRow['wantedName'];
    } else {
        $mostWanted = "";
    }

    $maxMoneyPlayerSQL = $connectionSQLi->query("SELECT name, (cash + bankacc) AS maxmoney FROM players ORDER BY maxmoney DESC LIMIT 1");
    if ($maxMoneyPlayerSQL->num_rows > 0) {
        $maxMoneyPlayerRow = $maxMoneyPlayerSQL->fetch_assoc();
        $maxMoneyPlayer =  $maxMoneyPlayerRow['name'];
    } else {
        $maxMoneyPlayer = "";
    }

    $countMaxPlayerHousesSQL = $connectionSQLi->query("SELECT pid, COUNT(*) AS counthouses FROM houses GROUP BY pid ORDER BY counthouses DESC LIMIT 1");
    if ($countMaxPlayerHousesSQL->num_rows > 0) {
        $countMaxPlayerHousesRow1 = $countMaxPlayerHousesSQL->fetch_assoc();
        $countMaxPlayerHousesNumnber = $countMaxPlayerHousesRow1['pid'];
    } else {
        $countMaxPlayerHousesNumnber = "";
    }
    $maxPlayerHouseSQL = $connectionSQLi->query("SELECT name FROM players WHERE pid='$countMaxPlayerHousesNumnber'");
    if ($maxPlayerHouseSQL->num_rows > 0) {
        $maxPlayerHouseRow = $maxPlayerHouseSQL->fetch_assoc();
        $maxPlayerHouse = $maxPlayerHouseRow['name'];
    }

    $countMaxPlayerTotalVehiclesSQL = $connectionSQLi->query("SELECT pid, COUNT(*) AS countvehicles FROM vehicles GROUP BY pid ORDER BY countvehicles DESC LIMIT 1");
    $countMaxPlayerTotalCarSQL = $connectionSQLi->query("SELECT pid, COUNT(*) AS countcar FROM vehicles WHERE type='Car' GROUP BY pid ORDER BY countcar DESC LIMIT 1");
    $countMaxPlayerTotalAirSQL = $connectionSQLi->query("SELECT pid, COUNT(*) AS countair FROM vehicles WHERE type='Air' GROUP BY pid ORDER BY countair DESC LIMIT 1");
    $countMaxPlayerTotalShipSQL = $connectionSQLi->query("SELECT pid, COUNT(*) AS countship FROM vehicles WHERE type='Ship' GROUP BY pid ORDER BY countship DESC LIMIT 1");
    $countMaxPlayerTotalOtherSQL = $connectionSQLi->query("SELECT pid, COUNT(*) AS countother FROM vehicles WHERE type!='Car' AND type!='Air' AND type!='Ship' GROUP BY pid ORDER BY countother DESC LIMIT 1");
    if ($countMaxPlayerTotalVehiclesSQL->num_rows > 0) {
        $countMaxPlayerTotalVehiclesRow = $countMaxPlayerTotalVehiclesSQL->fetch_assoc();
        $countMaxPlayerTotalVehiclesNumnber = $countMaxPlayerTotalVehiclesRow['pid'];
        $countMaxPlayerTotalCarRow = $countMaxPlayerTotalCarSQL->fetch_assoc();
        $countMaxPlayerTotalCarNumnber = $countMaxPlayerTotalCarRow['pid'];
        $countMaxPlayerTotalAirRow = $countMaxPlayerTotalAirSQL->fetch_assoc();
        $countMaxPlayerTotalAirNumnber = $countMaxPlayerTotalAirRow['pid'];
        $countMaxPlayerTotalShipRow = $countMaxPlayerTotalShipSQL->fetch_assoc();
        $countMaxPlayerTotalShipNumnber = $countMaxPlayerTotalShipRow['pid'];
        $countMaxPlayerTotalOtherRow = $countMaxPlayerTotalOtherSQL->fetch_assoc();
        $countMaxPlayerTotalOtherNumnber = $countMaxPlayerTotalOtherRow['pid'];
    } else {
        $countMaxPlayerTotalVehiclesNumnber = "";
        $countMaxPlayerTotalCarNumnber = "";
        $countMaxPlayerTotalAirNumnber = "";
        $countMaxPlayerTotalShipNumnber = "";
        $countMaxPlayerTotalOtherNumnber = "";
    }
    $maxPlayerTotalVehiclesSQL = $connectionSQLi->query("SELECT name FROM players WHERE pid='$countMaxPlayerTotalVehiclesNumnber'");
    $maxPlayerTotalCarSQL = $connectionSQLi->query("SELECT name FROM players WHERE pid='$countMaxPlayerTotalCarNumnber'");
    $maxPlayerTotalAirSQL = $connectionSQLi->query("SELECT name FROM players WHERE pid='$countMaxPlayerTotalAirNumnber'");
    $maxPlayerTotalShipSQL = $connectionSQLi->query("SELECT name FROM players WHERE pid='$countMaxPlayerTotalShipNumnber'");
    $maxPlayerTotalOtherSQL = $connectionSQLi->query("SELECT name FROM players WHERE pid='$countMaxPlayerTotalOtherNumnber'");
    if ($maxPlayerTotalVehiclesSQL->num_rows > 0) {
        $maxPlayerTotalVehiclesRow = $maxPlayerTotalVehiclesSQL->fetch_assoc();
        $maxPlayerTotalVehicles = $maxPlayerTotalVehiclesRow['name'];
        $maxPlayerTotalCarRow = $maxPlayerTotalCarSQL->fetch_assoc();
        $maxPlayerTotalCar = $maxPlayerTotalCarRow['name'];
        $maxPlayerTotalAirRow = $maxPlayerTotalAirSQL->fetch_assoc();
        $maxPlayerTotalAir = $maxPlayerTotalAirRow['name'];
        $maxPlayerTotalShipRow = $maxPlayerTotalShipSQL->fetch_assoc();
        $maxPlayerTotalShip = $maxPlayerTotalShipRow['name'];
        $maxPlayerTotalOtherRow = $maxPlayerTotalOtherSQL->fetch_assoc();
        $maxPlayerTotalOther = $maxPlayerTotalOtherRow['name'];
    }
    
    include "templates/head.html";
?>

<body>
    <?php if ($userIP != "127.0.0.1") { ?>
        <a class="btn btn-danger rounded-0 p-2 py-1 position-fixed start-0 mt-3" title="Cerrar Session" href="./cloce">X</a>
    <?php } ?>
    <div class="ALW_MainContent mx-5">
        <div class="ALW_HeadMenu d-flex gap-2">
            <div>
                <h1 class="text-truncate">Life-Web 5.0.0</h1>
            </div>
        </div>
        <div class="border border-1 d-flex flex-column p-1 mb-1">
            <h3 class="text-center">Server Statistics</h3>
            <span class="border border-1 border-top-0 d-flex"></span>
            <div class="d-flex gap-1 mt-1 text-truncate overflow-auto pb-3">
                <div class="border border-1 p-1">
                    <p>    
                        <div class="d-flex gap-1 justify-content-center pb-1">
                            Vehicles: <?php echo $countTotalVehicles; ?>
                            <span class="border border-1 border-end-0 mt-1"></span>
                            History: <?php echo $vehiclesTotalHistory; ?>
                        </div>
                        <span class="border border-1 border-top-0 d-flex"></span>
                        <div class="d-flex gap-1">
                            <div>
                                Cop: <?php echo $countVehiclesCop; ?>
                                <br>Med: <?php echo $countVehiclesMed; ?>
                                <br>Civ: <?php echo $countVehiclesCiv; ?>
                            </div>
                            <span class="border border-1 border-end-0 mt-1"></span>
                            <div>
                                Air: <?php echo $countVehiclesAir; ?>
                                <br>Car: <?php echo $countVehiclesCar; ?>
                                <br>Ship: <?php echo $countVehiclesShip; ?>
                                <br>Other: <?php echo $countVehiclesOther; ?>
                            </div>
                            <span class="border border-1 border-end-0 mt-1"></span>
                            <div>
                                CivAir: <?php echo $countVehiclesCivAir; ?>
                                <br>CivCar: <?php echo $countVehiclesCivCar; ?>
                                <br>CivShip: <?php echo $countVehiclesCivShip; ?>
                                <br>CivOther: <?php echo $countVehiclesCivOther; ?>
                            </div>
                            <span class="border border-1 border-end-0 mt-1"></span>
                            <div>
                                CopAir: <?php echo $countVehiclesCopAir; ?>
                                <br>CopCar: <?php echo $countVehiclesCopCar; ?>
                                <br>CopShip: <?php echo $countVehiclesCopShip; ?>
                                <br>CopOther: <?php echo $countVehiclesCopOther; ?>
                            </div>
                            <span class="border border-1 border-end-0 mt-1"></span>
                            <div>
                                MedAir: <?php echo $countVehiclesMedAir; ?>
                                <br>MedCar: <?php echo $countVehiclesMedCar; ?>
                                <br>MedShip: <?php echo $countVehiclesMedShip; ?>
                                <br>MedOther: <?php echo $countVehiclesMedOther; ?>
                            </div>
                            <span class="border border-1 border-end-0 mt-1"></span>
                            <div>
                                maxCar: <?php echo $maxPlayerTotalCar; ?>
                                <br>maxAir: <?php echo $maxPlayerTotalAir; ?>
                                <br>maxShip: <?php echo $maxPlayerTotalShip; ?>
                                <br>maxOther: <?php echo $maxPlayerTotalOther; ?>
                            </div>
                            <span class="border border-1 border-end-0 mt-1"></span>
                            <div>
                                maxVehicles: <?php echo $maxPlayerTotalVehicles; ?>
                            </div>
                        </div>
                    </p>
                </div>
                <div class="border border-1 p-1">
                    <p class="text-center">Wanted: <?php echo $countTotalWanted; ?></p>    
                    <span class="border border-1 border-top-0 d-flex"></span>
                    <div class="d-flex gap-1">
                        <div>
                            <p>
                                Active: <?php echo $countTotalMostWanted; ?>
                                <br>Arrested: <span class="text-warning"><?php echo $countArrested; ?></span>
                                <br>Bounty: <span class="text-success">$<?php echo $sumBountyFormat; ?></span>
                                <br>Blacklist: <span class="text-danger"><?php echo $countBanned; ?></span>
                            </p>
                        </div>
                        <span class="border border-1 border-end-0 mt-1"></span>
                        <div>
                            <p>
                                MostWanted: <?php echo $mostWanted; ?>
                                <br>vehicleBlacklist: <?php echo $countTotalVehiclesBlacklist; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="border border-1 p-1">
                    <div class="d-flex gap-1 justify-content-center pb-1">
                        <p>Players: <?php echo $countTotalPlayers; ?></p>
                        <span class="border border-1 border-end-0 mt-1"></span>
                        <p> History: <?php echo $playersTotalHistory; ?></p>
                    </div>
                    <span class="border border-1 border-top-0 d-flex"></span>
                    <div class="d-flex gap-1">
                        <div>
                            <p>
                                Cop: <?php echo $countCopPlayers; ?>
                                <br>Med: <?php echo $countMedPlayers; ?>
                                <br>Civ: <?php echo $countCivPlayers; ?>
                                <br>Adm: <?php echo $countAdminPlayers; ?>
                            </p>
                        </div>
                        <span class="border border-1 border-end-0 mt-1"></span>
                        <div>
                            Cash: <span class="text-success">$<?php echo $PlayerTotalCashFormat; ?></span>
                            <br>Bank: <span class="text-success">$<?php echo $PlayerTotalBankaccFormat; ?></span>
                            <br>Donnor: <?php echo $countDonnorlayers; ?></span>
                        </div>
                        <span class="border border-1 border-end-0 mt-1"></span>
                        <div>
                            maxCash: <?php echo $maxCashPlayer; ?>
                            <br>maxBank: <?php echo $maxBankaccPlayer; ?>
                            <br>maxMoney: <?php echo $maxMoneyPlayer; ?>
                        </div>
                    </div>
                </div>
                <div class="border border-1 p-1">
                    <div class="d-flex gap-1 justify-content-center pb-1">
                        <p>Houses: <?php echo $countTotalHouses; ?></p>
                        <span class="border border-1 border-end-0 mt-1"></span>
                        <p> History: <?php echo $housesTotalHistory; ?></p>
                    </div>
                    <span class="border border-1 border-top-0 d-flex"></span>
                    <div class="d-flex gap-1">
                        <div>
                            <p>
                                Garage: <?php echo $countTotalGarage; ?>
                                <br>Containers: <?php echo $countTotalContainers; ?>
                                <br>maxHouses: <?php echo $maxPlayerHouse; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="border border-1 p-1">
                    <div class="d-flex gap-1 justify-content-center pb-1">
                        <p class="text-center">Gangs: <?php echo $countTotalGangs; ?></p>
                        <span class="border border-1 border-end-0 mt-1"></span>
                        <p> History: <?php echo $gangsTotalHistory; ?></p>
                    </div>
                    <span class="border border-1 border-top-0 d-flex"></span>
                    <p>
                        Bank: <span class="text-success">$<?php echo $GangTotalBankaccFormat; ?></span>
                    </p>
                </div>
            </div>
        </div>

        <table class="ALW_userTable table table-responsive table-dark table-hover mb-3 overflow-auto">
            <thead>
                <tr>
                    <th></th>
                    <th class="text-center">uid</th>
                    <th class="text-center">name</th>
                    <th class="text-center">aliases</th>
                    <th class="text-center">cash</th>
                    <th class="text-center">bankacc</th>
                    <th class="text-center">coplevel</th>
                    <th class="text-center">mediclevel</th>
                    <th class="text-center">donorlevel</th>
                    <th class="text-center">adminlevel</th>
                    <th class="text-center">arrested</th>
                    <th class="text-center">blacklist</th>
                    <th class="text-center">gang</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sentenciaSQL = $connectionPDO->prepare("SELECT * FROM players ORDER BY uid ASC");
                $sentenciaSQL->execute();
                $userSearch = $sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
                foreach ($userSearch as $row) {
                    $rowAliases = str_replace('"[`', '', $row['aliases']);
                    $rowAliases2 = str_replace('`]"', '', $rowAliases);

                    $cashNumber = $row['cash'];
                    $cashFormat = number_format($cashNumber, '0', ',', '.');

                    $bankaccNumber = $row['bankacc'];
                    $bankaccFormat = number_format($bankaccNumber, '0', ',', '.');
                ?>
                    <tr>
                        <th class="text-center m-0 p-0 text-truncate btn btn-secondary rounded-0 w-100"><a href="userCheck?pid=<?php echo $row['pid'] ?>&name=<?php echo $row['name'] ?>&uid=<?php echo $row['uid'] ?>">-></a></th>
                        <th class="text-center"><?php echo $row['uid'] ?></th>
                        <th class="ps-1"><?php echo $row['name'] ?></th>
                        <th class="ps-1"><?php echo $rowAliases2 ?></th>
                        <th class="ps-1 text-success">$<?php echo $cashFormat ?></th>
                        <th class="ps-1 text-success">$<?php echo $bankaccFormat ?></th>
                        <th class="text-center <?php echo ($row['coplevel'] >= 1)?"text-bg-primary":""; ?>"><?php echo $row['coplevel'] ?></th>
                        <th class="text-center <?php echo ($row['mediclevel'] >= 1)?"text-bg-success":""; ?>"><?php echo $row['mediclevel'] ?></th>
                        <th class="text-center <?php echo ($row['donorlevel'] >= 1)?"text-bg-info":""; ?>"><?php echo $row['donorlevel'] ?></th>
                        <th class="text-center <?php echo ($row['adminlevel'] >= 1)?"text-bg-light":""; ?>"><?php echo $row['adminlevel'] ?></th>
                        <th class="text-center <?php echo ($row['arrested'] >= 1)?"text-bg-warning":""; ?>"><?php echo $row['arrested'] ?></th>
                        <th class="text-center <?php echo ($row['blacklist'] >= 1)?"text-bg-danger":""; ?>"><?php echo $row['blacklist'] ?></th>
                    <?php
                        $userid = $row['pid'];
                        $sentenciaSQL2 = $connectionPDO->prepare("SELECT owner,id FROM gangs WHERE members LIKE '%$userid%'");
                        $sentenciaSQL2->execute();
                        $userSearch2 = $sentenciaSQL2->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($userSearch2 as $row2) {
                            if ($userid == $row2['owner']) { ?>
                                <th class="text-center text-bg-secondary"><?php echo $row2['id'] ?></th>
                            <?php } else { ?>
                                <th class="text-center"><?php echo $row2['id'] ?></th>
                            <?php }
                            
                        }
                } ?>
                    </tr>
            </tbody>
        </table>
    </div>
</body>
<script src="./libraries/bootstrap/js/bootstrap.min.js"></script>
</html>