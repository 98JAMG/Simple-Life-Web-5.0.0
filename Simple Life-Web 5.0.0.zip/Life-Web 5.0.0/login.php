<?php
    $userIP = $_SERVER['REMOTE_ADDR'];
    $witheListIP = "192.168.1.100 | 192.168.1.101 | 192.168.1.95 | 192.168.1.40";
    
    if ($userIP == "127.0.0.1") {
        session_start();
        $_SESSION['loginuser']="localAdmin";
        header("location:index");
    }elseif (!preg_match("/\b$userIP\b/", $witheListIP)) {
        session_destroy();
        header("location:404");
    }

    include "templates/head.html";
?>
<body>
    <div class="text-center mt-5">
        <h1>Life-Web 5.0.0</h1>
        <small id="emailHelp" class="form-text">por JAMG</small>
    </div>
    <form action="validation" method="POST" class="m-auto w-25 mt-5 container-sm d-flex flex-column gap-2">
        <div class = "form-group">
            <label for="user">Usuario</label>
            <input required type="text" class="form-control text-black rounded-0" id="user" name="loginuser">
        </div>
        <div class="form-group">
            <label for="pass">Contraseña</label>
            <input required type="password" class="form-control text-black rounded-0" id="pass" name="loginpass">
        </div>
        <button type="submit" class="btn btn-primary rounded-0 py-1 px-2 w-25 align-self-center mt-1">Ingresar</button>
    </form>
</body>
<script src="./libraries/bootstrap/js/bootstrap.min.js"></script>
</html>