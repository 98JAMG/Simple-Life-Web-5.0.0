<?php
    session_start();
    if (!isset($_SESSION['loginuser'])) {
        header("location:login");
    }
    include "database.php";
    
    $pidGET = $_GET['pid'];
    $uidGET = $_GET['uid'];
    $nameGET = $_GET['name'];
    $act = (isset($_POST['act']))?$_POST['act']:"0";
    $del = (isset($_POST['del']))?$_POST['del']:"0";

    $playersSQL = $connectionPDO->prepare("SELECT * FROM players WHERE pid='$pidGET'");
    $containersSQL = $connectionPDO->prepare("SELECT * FROM containers WHERE pid='$pidGET'");
    $gangsSQL = $connectionPDO->prepare("SELECT * FROM gangs WHERE owner='$pidGET'");
    $housesSQL = $connectionPDO->prepare("SELECT * FROM houses WHERE pid='$pidGET'");
    $vehiclesSQL = $connectionPDO->prepare("SELECT * FROM vehicles WHERE pid='$pidGET'");
    $wantedSQL = $connectionPDO->prepare("SELECT * FROM wanted WHERE wantedID='$pidGET'");
    $playersSQL->execute();
    $containersSQL->execute();
    $gangsSQL->execute();
    $housesSQL->execute();
    $vehiclesSQL->execute();
    $wantedSQL->execute();
    $playersDataLAZY = $playersSQL->fetch(PDO::FETCH_LAZY);
    $containersDataLAZY = $containersSQL->fetch(PDO::FETCH_LAZY);
    $gangsDataLAZY = $gangsSQL->fetch(PDO::FETCH_LAZY);
    $housesDataLAZY = $housesSQL->fetch(PDO::FETCH_LAZY);
    $vehiclesDataLAZY = $vehiclesSQL->fetch(PDO::FETCH_LAZY);
    $wantedDataLAZY = $wantedSQL->fetch(PDO::FETCH_LAZY);
    
    $playersSQL2 = $connectionPDO->prepare("SELECT * FROM players WHERE pid='$pidGET'");
    $playersSQL3 = $connectionPDO->prepare("SELECT * FROM players ORDER BY uid ASC");
    $containersSQL2 = $connectionPDO->prepare("SELECT * FROM containers WHERE pid='$pidGET'");
    $gangsSQL2 = $connectionPDO->prepare("SELECT * FROM gangs WHERE owner='$pidGET'");
    $housesSQL2 = $connectionPDO->prepare("SELECT * FROM houses WHERE pid='$pidGET'");
    $vehiclesSQL2 = $connectionPDO->prepare("SELECT * FROM vehicles WHERE pid='$pidGET'");
    $wantedSQL2 = $connectionPDO->prepare("SELECT * FROM wanted WHERE wantedID='$pidGET'");
    $playersSQL2->execute();
    $playersSQL3->execute();
    $containersSQL2->execute();
    $gangsSQL2->execute();
    $housesSQL2->execute();
    $vehiclesSQL2->execute();
    $wantedSQL2->execute();
    $playersDataASSOC = $playersSQL2->fetchAll(PDO::FETCH_ASSOC);
    $playersDataASSOC2 = $playersSQL3->fetchAll(PDO::FETCH_ASSOC);
    $containersDataASSOC = $containersSQL2->fetchAll(PDO::FETCH_ASSOC);
    $gangsDataASSOC = $gangsSQL2->fetchAll(PDO::FETCH_ASSOC);
    $housesDataASSOC = $housesSQL2->fetchAll(PDO::FETCH_ASSOC);
    $vehiclesDataASSOC = $vehiclesSQL2->fetchAll(PDO::FETCH_ASSOC);
    $wantedDataASSOC = $wantedSQL2->fetchAll(PDO::FETCH_ASSOC);

    $newCash = (isset($_POST['newCash']))?$_POST['newCash']:"";
    $newBankacc = (isset($_POST['newBankacc']))?$_POST['newBankacc']:"";
    $newCoplvl = (isset($_POST['newCoplvl']))?$_POST['newCoplvl']:"";
    $newMedlvl = (isset($_POST['newMedlvl']))?$_POST['newMedlvl']:"";
    $newDonorlvl = (isset($_POST['newDonorlvl']))?$_POST['newDonorlvl']:"";
    $newAdminlvl = (isset($_POST['newAdminlvl']))?$_POST['newAdminlvl']:"";
    $isBlacklisted = (isset($_POST['isBlacklisted']))?$_POST['isBlacklisted']:"";
    $isArrested = (isset($_POST['isArrested']))?$_POST['isArrested']:"";
    $containerSelected = (isset($_POST['containerSelected']))?$_POST['containerSelected']:"";
    $houseSelected = (isset($_POST['houseSelected']))?$_POST['houseSelected']:"";
    $vehicleSelected = (isset($_POST['vehicleSelected']))?$_POST['vehicleSelected']:"";
    $gangLeaderSelected = (isset($_POST['gangLeaderSelected']))?$_POST['gangLeaderSelected']:"";
    $delCrimes = (isset($_POST['delCrimes']))?$_POST['delCrimes']:"false";
    $clearCrimes = (isset($_POST['clearCrimes']))?$_POST['clearCrimes']:"false";
    $sumrestcash = (isset($_POST['sumrestcash']))?$_POST['sumrestcash']:"";
    $sumrestbankacc = (isset($_POST['sumrestbankacc']))?$_POST['sumrestbankacc']:"";

    $accion = (isset($_POST['accion']))?$_POST['accion']:"";
    $isTrue = (isset($_POST['isTrue']))?$_POST['isTrue']:"false";
    $continuetodel = (isset($_POST['continuetodel']))?$_POST['continuetodel']:"false";

    switch ($accion) {
        case 'Actualizar':
            if ($isTrue == 'true') {
                $ACTplayersTableSQL = $connectionPDO->prepare("UPDATE players SET cash=:cash,bankacc=:bankacc,coplevel=:coplevel,mediclevel=:mediclevel,donorlevel=:donorlevel,adminlevel=:adminlevel,blacklist=:blacklist,arrested=:arrested,civ_stats=:civ_stats,cop_stats=:cop_stats,med_stats=:med_stats,civ_position=:civ_position WHERE pid=:pid");
                $ACTplayersTableSQL->bindParam(':pid',$pidGET);
                if ($newCash > 0) {
                    if ($sumrestcash == "res") {
                        $sumNewCashNegative = $newCash - $playersDataLAZY['cash'];
                        $sumNewCash = $sumNewCashNegative * -1;
                        ($sumNewCash <= 0) ? $sumNewCash = 0: "";
                    } else {
                        $sumNewCash = $newCash + $playersDataLAZY['cash'];  
                    }
                } else {
                    $sumNewCash = $playersDataLAZY['cash'];
                }
                $ACTplayersTableSQL->bindParam(':cash',$sumNewCash);
                if ($newBankacc > 0) {
                    if ($sumrestbankacc == "res") {
                        $sumNewBankaccNegative = $newBankacc - $playersDataLAZY['bankacc'];
                        $sumNewBankacc = $sumNewBankaccNegative * -1;
                        ($sumNewBankacc <= 0) ? $sumNewBankacc = 0: "";
                    } else {
                        $sumNewBankacc = $newBankacc + $playersDataLAZY['bankacc'];
                    }
                } else {
                    $sumNewBankacc = $playersDataLAZY['bankacc'];
                }
                $ACTplayersTableSQL->bindParam(':bankacc',$sumNewBankacc);
                $ACTplayersTableSQL->bindParam(':coplevel',$newCoplvl);
                $ACTplayersTableSQL->bindParam(':mediclevel',$newMedlvl);
                $ACTplayersTableSQL->bindParam(':donorlevel',$newDonorlvl);
                $ACTplayersTableSQL->bindParam(':adminlevel',$newAdminlvl);
                $ACTplayersTableSQL->bindParam(':blacklist',$isBlacklisted);
                $ACTplayersTableSQL->bindParam(':arrested',$isArrested);
                $ACTplayersTableSQL->bindParam(':civ_stats',$playersDataLAZY['civ_stats']);
                $ACTplayersTableSQL->bindParam(':cop_stats',$playersDataLAZY['cop_stats']);
                $ACTplayersTableSQL->bindParam(':med_stats',$playersDataLAZY['med_stats']);
                $ACTplayersTableSQL->bindParam(':civ_position',$playersDataLAZY['civ_position']);
                $ACTplayersTableSQL->execute();
                if ($delCrimes == "true") {
                    $DELcrimesSQL = $connectionPDO->prepare("DELETE FROM wanted WHERE wantedID=:pid");
                    $DELcrimesSQL->bindParam(':pid',$pidGET);
                    $DELcrimesSQL->execute();
                }
                if ($clearCrimes == "true") {
                    $clearCrimesVAR = "[]";
                    $clearBountyVAR = "0";
                    $clearActiveVAR = "0";
                    $CLEARcrimesSQL = $connectionPDO->prepare("UPDATE wanted SET wantedCrimes=:clearcrime,wantedBounty=:clearbounty,active=:clearactive WHERE wantedID=:pid");
                    $CLEARcrimesSQL->bindParam(':pid',$pidGET);
                    $CLEARcrimesSQL->bindParam(':clearcrime',$clearCrimesVAR);
                    $CLEARcrimesSQL->bindParam(':clearbounty',$clearBountyVAR);
                    $CLEARcrimesSQL->bindParam(':clearactive',$clearActiveVAR);
                    $CLEARcrimesSQL->bindParam(':pid',$pidGET);
                    $CLEARcrimesSQL->execute();
                }
                if ($containerSelected != 'none') {
                    $DELcontainerSQL = $connectionPDO->prepare("DELETE FROM containers WHERE id=:cid AND pid=:pid");
                    $DELcontainerSQL->bindParam(':cid',$containerSelected);
                    $DELcontainerSQL->bindParam(':pid',$pidGET);
                    $DELcontainerSQL->execute();
                }
                if ($houseSelected != 'none') {
                    $DELhouseSQL = $connectionPDO->prepare("DELETE FROM houses WHERE id=:cid AND pid=:pid");
                    $DELhouseSQL->bindParam(':cid',$houseSelected);
                    $DELhouseSQL->bindParam(':pid',$pidGET);
                    $DELhouseSQL->execute();
                }
                if ($vehicleSelected != 'none') {
                    $DELvehicleSQL = $connectionPDO->prepare("DELETE FROM vehicles WHERE id=:cid AND pid=:pid");
                    $DELvehicleSQL->bindParam(':cid',$vehicleSelected);
                    $DELvehicleSQL->bindParam(':pid',$pidGET);
                    $DELvehicleSQL->execute();
                }
                if ($gangLeaderSelected != $pidGET) {
                    if (preg_match("/\b$gangLeaderSelected\b/", $gangsDataLAZY['members'])) {
                        $CHANGEleaderSQL = $connectionPDO->prepare("UPDATE gangs SET owner=:owner WHERE id=:id");
                        $CHANGEleaderSQL->bindParam(':owner',$gangLeaderSelected);
                    } else {
                        $strMembers = str_replace($pidGET, $gangLeaderSelected, $gangsDataLAZY['members']);
                        $CHANGEleaderSQL = $connectionPDO->prepare("UPDATE gangs SET owner=:owner,members=:members WHERE id=:id");
                        $CHANGEleaderSQL->bindParam(':owner',$gangLeaderSelected);
                        $CHANGEleaderSQL->bindParam(':members',$strMembers);
                    }
                    $CHANGEleaderSQL->bindParam(':id',$gangsDataLAZY['id']);
                    $CHANGEleaderSQL->execute();
                }
                header("location:userEdit?pid=$pidGET&name=$nameGET&uid=$uidGET&act=1&del=0");
            } else {
                echo '
                    <div class="alert alert-dismissible fade show text-center text-black position-fixed bottom-0 w-100 bg-warning border border-0 rounded-0 p-1" role="alert">
                        <button type="button" class="btn-close me-3 mt-2" data-bs-dismiss="alert" aria-label="Close"></button>
                        Deve escribir true para continuar, ha escrito <span class="bg-danger px-1">'.$isTrue.'</span>
                    </div>
                ';
            }
            break;
        case 'Eliminar':
            if ($isTrue == '-del gang' && isset($gangsDataLAZY['owner'])) {
                $DELgangsTableSQL = $connectionPDO->prepare("DELETE FROM gangs WHERE owner=:pid");
                $DELgangsTableSQL->bindParam(':pid',$pidGET);
                $DELgangsTableSQL->execute();
                header("location:userEdit?pid=$pidGET&name=$nameGET&uid=$uidGET&act=0&del=0");
                break;
            }
            if ($isTrue == 'true') {
                if (!isset($gangsDataLAZY['owner']) == $pidGET || $continuetodel == "true") {
                    $DELplayerTableSQL = $connectionPDO->prepare("DELETE FROM players WHERE pid=:pid");
                    $DELplayerTableSQL->bindParam(':pid',$pidGET);
                    $DELplayerTableSQL->execute();
                    if (isset($gangsDataLAZY['owner'])) {
                        $DELgangsTableSQL = $connectionPDO->prepare("DELETE FROM gangs WHERE owner=:pid");
                        $DELgangsTableSQL->bindParam(':pid',$pidGET);
                        $DELgangsTableSQL->execute();
                    }
                    $DELgangsmemberTableSQL = $connectionPDO->prepare("SELECT * FROM gangs WHERE members LIKE '%$pidGET%'");
                    $DELgangsmemberTableSQL->execute();
                    $DELgangsmemberTable = $DELgangsmemberTableSQL->fetchAll(PDO::FETCH_ASSOC);
                    if (isset($DELgangsmemberTableSQL)) {
                        foreach ($DELgangsmemberTable as $member) {
                            $strmember = str_replace($pidGET, '', $member['members']);
                            $strmember = str_replace(',``,', ',', $strmember);
                            $strmember = str_replace('`,``', '`', $strmember);
                            $strmember = str_replace('``,`', '`', $strmember);
                        }
                        $DELgangsmemberTableFormatSQL = $connectionPDO->prepare("UPDATE gangs SET members=:members WHERE members LIKE '%$pidGET%'");
                        $DELgangsmemberTableFormatSQL->bindParam(':members',$strmember);
                        $DELgangsmemberTableFormatSQL->execute();
                    }
                    $DELcontainersTableSQL = $connectionPDO->prepare("DELETE FROM containers WHERE pid=:pid");
                    $DELhousesTableSQL = $connectionPDO->prepare("DELETE FROM houses WHERE pid=:pid");
                    $DELvehiclesTableSQL = $connectionPDO->prepare("DELETE FROM vehicles WHERE pid=:pid");
                    $DELwantedTableSQL = $connectionPDO->prepare("DELETE FROM wanted WHERE wantedID=:pid");
                    $DELcontainersTableSQL->bindParam(':pid',$pidGET);
                    $DELhousesTableSQL->bindParam(':pid',$pidGET);
                    $DELvehiclesTableSQL->bindParam(':pid',$pidGET);
                    $DELwantedTableSQL->bindParam(':pid',$pidGET);
                    $DELcontainersTableSQL->execute();
                    $DELhousesTableSQL->execute();
                    $DELvehiclesTableSQL->execute();
                    $DELwantedTableSQL->execute();
                    header("location:index?previousAction=$accion&previousVictim=$nameGET");
                } else {
                    echo '
                        <form method="POST">
                            <div class="position-fixed d-flex flex-column gap-1 text-center bg-dark z-3 top-25 bottom-50 w-100 h-25">
                                <h2 class="text-warning">Alerta!</h2>
                                <hr>
                                <p>Este usuario lidera la banda <span class="bg-danger px-1">'. $gangsDataLAZY['name'] .'</span> , si esta cuenta es eliminada tambien se eliminara esta banda.<br></p>
                                <hr>
                                <div>
                                    <input type="hidden" name="continuetodel" value="true">
                                    <input type="hidden" name="isTrue" value="true">
                                    <button type="submit" name="accion" value="Eliminar" class="btn btn-danger rounded-0 p-1" title="Elimine esta cuenta y todos sus objetos vinculados.">Eliminar</button>
                                    <button type="submit" name="accion" value="Cancelar" class="btn btn-success rounded-0 p-1">Cancelar</button>
                                </div>
                            </div>
                        </form>
                    ';
                }
            } else {
                echo "<p class='bg-warning py-1 w-100 text-center text-black position-fixed bottom-0'>Deve escribir true para continuar, ha escrito <span class='bg-danger px-1'>".$isTrue."</span></p>";
            }
            break;
        case 'Cancelar':
            header("location:userEdit?pid=$pidGET&name=$nameGET&uid=$uidGET&act=0&del=0");
            break;
    }

    $strAliases = str_replace('"[`', '', $playersDataLAZY['aliases']);
    $strAliases2 = str_replace('`]"', '', $strAliases);
    $cashNumber = $playersDataLAZY['cash'];
    $cashFormat = number_format($cashNumber, '0', ',', '.');
    $bankaccNumber = $playersDataLAZY['bankacc'];
    $bankaccFormat = number_format($bankaccNumber, '0', ',', '.');

    include "templates/head.html";
?>
<body>
    <div class="row justify-content-center align-items-center gap-1">
        <div class="col">
            <div class="d-flex align-items-center">
            <a class="btn btn-danger rounded-0 p-2" href="userCheck?pid=<?php echo $pidGET ?>&name=<?php echo $nameGET ?>&uid=<?php echo $uidGET ?>"><-</a>
                <h1 class="text-truncate">Life-Web 5.0.0 >> <?php echo $nameGET ?> >> <?php echo $pidGET ?></h1>
            </div>
        </div>
        <hr>
        <form method="POST">
            <div class="row gap-1 justify-content-center">
                <div class="col-2">
                    <div class="border border-1 p-1">
                        <p class="text-center">Ejecuta operaciones financieras</p><hr>
                        <div class="d-flex">
                            <select name="sumrestcash" class="form-control-plaintext border border-1 border-end-0 p-1 w-auto align-self-end">
                                <option class="text-black" value="sum">+</option>
                                <option class="text-black" value="res">-</option>
                            </select>
                            <div>
                                <label for="newCash">Efectivo actual:</label><span class="bg-success px-1 float-end">$<?php echo $cashFormat;?></span>
                                <input accept="number" type="text" class="form-control-plaintext border border-1 p-1" name="newCash" id="newCash" value="0">
                            </div>
                        </div>
                        <div class="d-flex">
                            <select name="sumrestbankacc" class="form-control-plaintext border border-1 border-end-0 p-1 w-auto align-self-end">
                                <option class="text-black" value="sum">+</option>
                                <option class="text-black" value="res">-</option>
                            </select>
                            <div>
                                <label for="newBankacc">Saldo actual:</label><span class="bg-success px-1 float-end">$<?php echo $bankaccFormat;?></span>
                                <input accept="number" type="text" class="form-control-plaintext border border-1 p-1" name="newBankacc" id="newBankacc" value="0">
                            </div>
                        </div>
                    </div>
                    <div id="grupo1" class="border border-1 p-1 mt-1">
                        <p class="text-center">Opciones extra</p><hr>
                        <div class="d-flex align-items-center gap-1">
                            <?php if ($playersDataLAZY['blacklist'] == 1) { ?>
                                <input class="form-check-input rounded-0" value="0" type="checkbox" name="isBlacklisted" id="isBlacklisted"><label class="form-check-label">Desbanear</label>
                            <?php } else { ?>
                                <input class="form-check-input rounded-0" value="1" type="checkbox" name="isBlacklisted" id="isBlacklisted"><label class="form-check-label">Banear</label>
                            <?php } ?>
                        </div>
                        <div class="d-flex align-items-center gap-1">
                            <?php if ($playersDataLAZY['arrested'] == 1) { ?>
                                <input class="form-check-input rounded-0" value="0" type="checkbox" name="isArrested" id="isArrested"><label class="form-check-label">Liberar</label>
                            <?php } else { ?>
                                <input class="form-check-input rounded-0" value="1" type="checkbox" name="isArrested" id="isArrested"><label class="form-check-label">Arrestar</label>
                            <?php } ?>
                        </div>
                        <?php if (isset($wantedDataLAZY['wantedID'])) { ?>
                            <?php if ($wantedDataLAZY['wantedCrimes'] != "[]") { ?>
                            <div class="d-flex align-items-center gap-1">
                                <input class="form-check-input rounded-0" value="true" type="checkbox" name="clearCrimes" id="clearCrimes"><label class="form-check-label">Limpiar Crimenes</label>
                            </div>
                            <?php } ?>
                            <div class="d-flex align-items-center gap-1">
                                <input class="form-check-input rounded-0" value="true" type="checkbox" name="delCrimes" id="delCrimes"><label class="form-check-label">Borrar Antecedentes Penales</label>
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="col-2 border border-1 p-1">
                    <p class="text-center">Administra niveles</p><hr>
                    <div>
                        <label for="newCoplvl">Nivel Policial (0-7):</label>
                        <input accept="number" class="form-control-plaintext border border-1 p-1" type="number" name="newCoplvl" id="newCoplvl" min="0" max="7" value="<?php echo $playersDataLAZY['coplevel'];?>">
                    </div>
                    <div>
                        <label for="newMedlvl">Nivel Medico (0-5):</label>
                        <input accept="number" class="form-control-plaintext border border-1 p-1" type="number" name="newMedlvl" id="newMedlvl" min="0" max="5" value="<?php echo $playersDataLAZY['mediclevel'];?>">
                    </div>
                    <div>
                        <label for="newDonorlvl">Descuento (0-5):</label>
                        <input accept="number" class="form-control-plaintext border border-1 p-1" type="number" name="newDonorlvl" id="newDonorlvl" min="0" max="5" value="<?php echo $playersDataLAZY['donorlevel'];?>">
                    </div>
                    <div>
                        <label for="newAdminlvl">Admin Power (0-5):</label>
                        <input accept="number" class="form-control-plaintext border border-1 p-1" type="number" name="newAdminlvl" id="newAdminlvl" min="0" max="5" value="<?php echo $playersDataLAZY['adminlevel'];?>">
                    </div>
                </div>
                <?php if (isset($containersDataLAZY['id']) || isset($housesDataLAZY['id']) || isset($vehiclesDataLAZY['id'])) { ?>
                <div class="col-2 border border-1 p-1">
                    <p class="text-center">Elimina activos</p><hr>
                    <?php if (isset($containersDataLAZY['id'])) { ?>
                    <div id="grupo2">
                        <label>Contenedores:</label><br><hr>
                        <?php foreach ($containersDataASSOC as $containerID) { ?>
                            <div class="float-start">
                                <input title="<?php echo $containerID['id'] ?>" class="m-1 form-check-input rounded-0" type="checkbox" name="containerSelected" value="<?php echo $containerID['id'] ?>"><?php echo $containerID['id'] ?></input>
                            </div>
                        <?php } ?>
                    </div>
                    <?php } ?>
                    <?php if (isset($housesDataLAZY['id'])) { ?>
                    <div id="grupo3" class="<?php echo (isset($containerID['id']))?"mt-4":""; ?>">
                        <label>Casas y Garages:</label><br><hr>
                        <?php foreach ($housesDataASSOC as $houseID) { ?>
                            <div class="float-start">
                                <input title="<?php echo $houseID['id']; ?>" class="m-1 form-check-input rounded-0" type="checkbox" name="houseSelected" value="<?php echo $houseID['id'] ?>"><span class="<?php echo ($houseID['garage'] == 1)?"text-decoration-underline":""; ?>"><?php echo $houseID['id'] ?></span></input>
                            </div>
                        <?php } ?>
                    </div>
                    <?php } ?>
                    <?php if (isset($vehiclesDataLAZY['id'])) { ?>
                    <div id="grupo4" class="<?php echo (isset($housesDataLAZY['id']) || isset($housesDataLAZY['id']))?"mt-4":""; ?>">
                        <label>Vehiculos:</label><br><hr>
                        <?php foreach ($vehiclesDataASSOC as $vehicleID) { ?>
                            <div class="float-start <?php echo ($vehicleID['blacklist'])?"text-danger":""; ?>">
                                <input title="<?php echo $vehicleID['id'].' - '.$vehicleID['classname'].' ['.$vehicleID['type'].']['.$vehicleID['side'].']' ?>" class="form-check-input rounded-0 m-1" type="checkbox" name="vehicleSelected" value="<?php echo $vehicleID['id'] ?>"><?php echo $vehicleID['id'] ?></input>
                            </div>
                        <?php } ?>
                    </div>                          
                    <?php } ?>
                </div>
                <?php } ?>
                <?php if (isset($gangsDataLAZY['owner']) == $pidGET) { ?>
                <div class="col-2 border border-1 p-1">
                    <p class="text-center">Gestiona la banda</p><hr>
                    <div>
                        <label for="gangleaderSelect">Lider de la banda:</label>
                        <select id="gangleaderSelect" class="form-control-plaintext border border-1 p-1" multiple="multiple" name="gangLeaderSelected" title="Selecciona un miembro de esta banda para ser el nuevo lider">
                            <option value="<?php echo $playersDataLAZY['pid'] ?>" selected></option>
                            <?php
                                foreach ($playersDataASSOC2 as $playerNameRow) {
                                    $memberAvailable = $playerNameRow['pid'];
                                    if ($playerNameRow['pid'] != $pidGET && preg_match("/\b$memberAvailable\b/", $gangsDataLAZY['members'])) { ?>
                                        <option value="<?php echo $playerNameRow['pid'] ?>"><?php echo $playerNameRow['uid'] ?> - <?php echo $playerNameRow['name'] ?></option>
                            <?php }} ?>
                        </select>
                    </div>
                </div>
                <?php } ?>
                <hr>
                <div class="row-12">
                    <div class="d-flex justify-content-center gap-1">
                        <button type="submit" name="accion" value="Actualizar" class="btn btn-success rounded-0 p-1" title="Envie los datos insertados.">Actualizar</button>
                        <input type="text" class="form-control-plaintext border border-1 p-1 text-center w-25" required name="isTrue" id="isTrue" value="" placeholder="escriba: 'true' para continuar.">
                        <button type="submit" name="accion" value="Eliminar" class="btn btn-danger rounded-0 p-1" title="Elimine esta cuenta y todos sus objetos vinculados.">Eliminar</button>
                    </div>
                    <?php if (isset($gangsDataLAZY['owner'])) { ?>
                    <p class="text-center">para eliminar la banda escribe: -del gang</p>
                    <?php } ?>
                </div>
            </div>
        </form>
    </div>
</body>
<script>
    const grupo1 = document.querySelectorAll('#grupo1 input[type="checkbox"]');
    const grupo2 = document.querySelectorAll('#grupo2 input[type="checkbox"]');
    const grupo3 = document.querySelectorAll('#grupo3 input[type="checkbox"]');
    const grupo4 = document.querySelectorAll('#grupo4 input[type="checkbox"]');

    // Crea una función para deseleccionar checkboxes de un grupo específico
    function deseleccionarOtros(checkboxes, checkboxActual) {
        checkboxes.forEach((checkbox) => {
            if (checkbox !== checkboxActual) {
                checkbox.checked = false;
            }
        });
    }

    // Asigna eventos para cada grupo de checkboxes
    grupo1.forEach((checkbox) => {
        checkbox.addEventListener('change', (event) => {
            if (event.target.checked) {
                deseleccionarOtros(grupo1, event.target);
            }
        });
    });
    grupo2.forEach((checkbox) => {
        checkbox.addEventListener('change', (event) => {
            if (event.target.checked) {
                deseleccionarOtros(grupo2, event.target);
            }
        });
    });
    grupo3.forEach((checkbox) => {
        checkbox.addEventListener('change', (event) => {
            if (event.target.checked) {
                deseleccionarOtros(grupo3, event.target);
            }
        });
    });
    grupo4.forEach((checkbox) => {
        checkbox.addEventListener('change', (event) => {
            if (event.target.checked) {
                deseleccionarOtros(grupo4, event.target);
            }
        });
    });
</script>
<script src="./libraries/bootstrap/js/bootstrap.min.js"></script>
</html>