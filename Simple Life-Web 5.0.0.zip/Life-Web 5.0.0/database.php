<?php	
    $host="localhost";
    $db="altislife_5.0.0";
    $user="root";
    $pass="";

    try {
        $connectionPDO=new PDO("mysql:host=$host;dbname=$db",$user,$pass);
        $connectionSQLi= new mysqli($host,$user,$pass,$db);
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
?>