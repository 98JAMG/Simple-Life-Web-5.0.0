<?php
    // ilegal vitems
    $cocaine_unprocessed = "cocaine_unprocessed";
    $cocaine_processed = "cocaine_processed";
    $heroin_unprocessed = "heroin_unprocessed";
    $heroin_processed = "heroin_processed";
    $cannabis = "cannabis";
    $marijuana = "marijuana";
    $turtle_raw = "turtle_raw";
    $spikeStrip = "spikeStrip";
    $lockpick = "lockpick";
    $goldbar = "goldbar";
    $blastingcharge = "blastingcharge";
    $boltcutter = "boltcutter";
    $defusekit = "defusekit";
?>