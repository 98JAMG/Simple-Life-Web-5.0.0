<?php
    session_start();
    if (!isset($_SESSION['loginuser'])) {
        header("location:login");
    }
    
    include "database.php";
    $pid = $_GET['pid'];
    $uid = $_GET['uid'];
    $name = $_GET['name'];

    $playersSQL = $connectionPDO->prepare("SELECT * FROM players WHERE pid='$pid'");
    $containersSQL = $connectionPDO->prepare("SELECT * FROM containers WHERE pid='$pid'");
    $gangsSQL = $connectionPDO->prepare("SELECT * FROM gangs WHERE owner='$pid'");
    $gangsSQL2 = $connectionPDO->prepare("SELECT * FROM gangs WHERE members LIKE '%$pid%'");
    $housesSQL = $connectionPDO->prepare("SELECT * FROM houses WHERE pid='$pid'");
    $vehiclesSQL = $connectionPDO->prepare("SELECT * FROM vehicles WHERE pid='$pid'");
    $wantedSQL = $connectionPDO->prepare("SELECT * FROM wanted WHERE wantedID='$pid'");
    $playersSQL->execute();
    $containersSQL->execute();
    $gangsSQL->execute();
    $gangsSQL2->execute();
    $housesSQL->execute();
    $vehiclesSQL->execute();
    $wantedSQL->execute();
    $playersData = $playersSQL->fetchAll(PDO::FETCH_ASSOC);
    $containersData = $containersSQL->fetchAll(PDO::FETCH_ASSOC);
    $gangsData = $gangsSQL->fetchAll(PDO::FETCH_ASSOC);
    $gangsData2 = $gangsSQL2->fetch(PDO::FETCH_LAZY);
    $housesData = $housesSQL->fetchAll(PDO::FETCH_ASSOC);
    $vehiclesData = $vehiclesSQL->fetchAll(PDO::FETCH_ASSOC);
    $wantedData = $wantedSQL->fetchAll(PDO::FETCH_ASSOC);

    $countVehiclesSQL = $connectionSQLi->query("SELECT id FROM vehicles WHERE pid='$pid'");
    $countVehicles = $countVehiclesSQL->num_rows;
    $countHousesSQL = $connectionSQLi->query("SELECT id FROM houses WHERE pid='$pid'");
    $countHouses = $countHousesSQL->num_rows;
    $countContainersSQL = $connectionSQLi->query("SELECT id FROM containers WHERE pid='$pid'");
    $countContainers = $countContainersSQL->num_rows;

    include "templates/head.html";
?>

<body>
    <div class="ALW_MainContent mx-5">
        <a class="btn btn-danger rounded-0 p-2 py-1 position-fixed start-0 mt-3" href="./index"><-</a>
        <div class="ALW_HeadMenu d-flex flex-column gap-2">
            <div class="d-flex align-items-center">
                <div>
                    <h1 class="text-truncate">Life-Web 5.0.0 >> <?php echo $name ?> >> <?php echo $pid ?></h1>
                </div>
                <div class="d-flex justify-content-end w-100">
                    <a class="btn btn-primary p-1 px-2 rounded-0" href="userEdit?pid=<?php echo $pid ?>&name=<?php echo $name ?>&uid=<?php echo $uid ?>">Edit</a>
                </div>
            </div>
            <hr>
            <div class="ALW_formMain mb-3 text-truncate">
                <h3>Table: Players</h3>
                <?php foreach ($playersData as $playersDataRow) {
                    $cashNumber = $playersDataRow['cash'];
                    $cashFormat = number_format($cashNumber, '0', ',', '.');

                    $bankaccNumber = $playersDataRow['bankacc'];
                    $bankaccFormat = number_format($bankaccNumber, '0', ',', '.');
                ?>
                    <div>
                        <strong class="text-decoration-underline text-info">uid:</strong> <?php echo $playersDataRow['uid'] ?>
                        <br><strong class="text-decoration-underline text-info">pid:</strong> <?php echo $playersDataRow['pid'] ?>
                        <br><strong class="text-decoration-underline text-info">nombre:</strong> <?php echo $playersDataRow['name'] ?>
                        <br><strong class="text-decoration-underline text-info">alias:</strong> <?php echo $playersDataRow['aliases'] ?>
                        <br><strong class="text-decoration-underline text-info">cash:</strong> <span class="text-success">$<?php echo $cashFormat ?></span>
                        <br><strong class="text-decoration-underline text-info">bankacc:</strong> <span class="text-success">$<?php echo $bankaccFormat ?></span>
                        <br><strong class="text-decoration-underline text-info">coplevel:</strong> <?php echo $playersDataRow['coplevel'] ?>
                        <br><strong class="text-decoration-underline text-info">mediclevel:</strong> <?php echo $playersDataRow['mediclevel'] ?>
                        <br><strong class="text-decoration-underline text-info">donorlevel:</strong> <?php echo $playersDataRow['donorlevel'] ?>
                        <br><strong class="text-decoration-underline text-info">adminlevel:</strong> <?php echo $playersDataRow['adminlevel'] ?>
                        <div class="d-flex"><strong class="text-decoration-underline text-info">civ_licenses:</strong>
                            <div class="overflow-auto"> <?php echo $playersDataRow['civ_licenses'] ?></div>
                        </div>
                        <div class="d-flex"><strong class="text-decoration-underline text-info">cop_licenses:</strong>
                            <div class="overflow-auto"> <?php echo $playersDataRow['cop_licenses'] ?></div>
                        </div>
                        <div class="d-flex"><strong class="text-decoration-underline text-info">med_licenses:</strong>
                            <div class="overflow-auto"> <?php echo $playersDataRow['med_licenses'] ?></div>
                        </div>
                        <div class="d-flex"><strong class="text-decoration-underline text-info">civ_gear:</strong>
                            <div class="overflow-auto"> <?php echo $playersDataRow['civ_gear'] ?></div>
                        </div>
                        <div class="d-flex"><strong class="text-decoration-underline text-info">cop_gear:</strong>
                            <div class="overflow-auto"> <?php echo $playersDataRow['cop_gear'] ?></div>
                        </div>
                        <div class="d-flex"><strong class="text-decoration-underline text-info">med_gear:</strong>
                            <div class="overflow-auto"> <?php echo $playersDataRow['med_gear'] ?></div>
                        </div>
                        <strong class="text-decoration-underline text-info">civ_stats:</strong> <?php echo $playersDataRow['civ_stats'] ?>
                        <br><strong class="text-decoration-underline text-info">cop_stats:</strong> <?php echo $playersDataRow['cop_stats'] ?>
                        <br><strong class="text-decoration-underline text-info">med_stats:</strong> <?php echo $playersDataRow['med_stats'] ?>
                        <br><strong class="text-decoration-underline text-info">arrested:</strong> <?php echo $playersDataRow['arrested'] ?>
                        <br><strong class="text-decoration-underline text-info">blacklist:</strong> <?php echo $playersDataRow['blacklist'] ?>
                        <br><strong class="text-decoration-underline text-info">civ_alive:</strong> <?php echo $playersDataRow['civ_alive'] ?>
                        <br><strong class="text-decoration-underline text-info">civ_position:</strong> <?php echo $playersDataRow['civ_position'] ?>
                        <br><strong class="text-decoration-underline text-info">playtime:</strong> <?php echo $playersDataRow['playtime'] ?>
                        <br><strong class="text-decoration-underline text-info">insert_time:</strong> <?php echo $playersDataRow['insert_time'] ?>
                        <br><strong class="text-decoration-underline text-info">last_seen:</strong> <?php echo $playersDataRow['last_seen'] ?>
                <?php } ?>
                    <br>
                    <br>
                    <h3>Table: Containers (<?php echo $countContainers ?>)</h3>
                    <div class="d-flex gap-2 overflow-auto">
                        <?php foreach ($containersData as $containersDataRow) { ?>
                            <div class="p-1 border border-1">
                                <strong class="text-decoration-underline text-info">id:</strong> <?php echo $containersDataRow['id'] ?>
                                <br><strong class="text-decoration-underline text-info">classname:</strong> <?php echo $containersDataRow['classname'] ?>
                                <br><strong class="text-decoration-underline text-info">pos:</strong> <?php echo $containersDataRow['pos'] ?>
                                <br><strong class="text-decoration-underline text-info">inventory:</strong> <?php echo $containersDataRow['inventory'] ?>
                                <br><strong class="text-decoration-underline text-info">gear:</strong> <?php echo $containersDataRow['gear'] ?>
                                <br><strong class="text-decoration-underline text-info">dir:</strong> <?php echo $containersDataRow['dir'] ?>
                                <br><strong class="text-decoration-underline text-info">active:</strong> <?php echo $containersDataRow['active'] ?>
                                <br><strong class="text-decoration-underline text-info">owned:</strong> <?php echo $containersDataRow['owned'] ?>
                                <br><strong class="text-decoration-underline text-info">insert_time:</strong> <?php echo $containersDataRow['insert_time'] ?>
                            </div>
                        <?php } ?>
                    </div>
                    <br>
                    <br>
                    <h3>Table: House (<?php echo $countHouses ?>)</h3>
                    <div class="d-flex gap-2 overflow-auto">
                        <?php foreach ($housesData as $housesDataRow) { ?>
                            <div class="p-1 border border-1">
                                <strong class="text-decoration-underline text-info">id:</strong> <?php echo $housesDataRow['id'] ?>
                                <br><strong class="text-decoration-underline text-info">pid:</strong> <?php echo $housesDataRow['pid'] ?>
                                <br><strong class="text-decoration-underline text-info">pos:</strong> <?php echo $housesDataRow['pos'] ?>
                                <br><strong class="text-decoration-underline text-info">owned:</strong> <?php echo $housesDataRow['owned'] ?>
                                <br><strong class="text-decoration-underline text-info">garage:</strong> <?php echo $housesDataRow['garage'] ?>
                                <br><strong class="text-decoration-underline text-info">insert_time:</strong> <?php echo $housesDataRow['insert_time'] ?>
                            </div>
                        <?php } ?>
                    </div>
                    <br>
                    <br>
                    <h3>Table: Vehicles (<?php echo $countVehicles ?>)</h3>
                    <div class="d-flex gap-2 overflow-auto">
                        <?php foreach ($vehiclesData as $vehiclesDataRow) { ?>
                            <div class="p-1 border border-1">
                                <strong class="text-decoration-underline text-info">id:</strong> <?php echo $vehiclesDataRow['id'] ?>
                                <br><strong class="text-decoration-underline text-info">pid:</strong> <?php echo $vehiclesDataRow['pid'] ?>
                                <br><strong class="text-decoration-underline text-info">side:</strong> <?php echo $vehiclesDataRow['side'] ?>
                                <br><strong class="text-decoration-underline text-info">classname:</strong> <?php echo $vehiclesDataRow['classname'] ?>
                                <br><strong class="text-decoration-underline text-info">type:</strong> <?php echo $vehiclesDataRow['type'] ?>
                                <br><strong class="text-decoration-underline text-info">alive:</strong> <?php echo $vehiclesDataRow['alive'] ?>
                                <br><strong class="text-decoration-underline text-info">blacklist:</strong> <?php echo $vehiclesDataRow['blacklist'] ?>
                                <br><strong class="text-decoration-underline text-info">active:</strong> <?php echo $vehiclesDataRow['active'] ?>
                                <br><strong class="text-decoration-underline text-info">plate:</strong> <?php echo $vehiclesDataRow['plate'] ?>
                                <br><strong class="text-decoration-underline text-info">color:</strong> <?php echo $vehiclesDataRow['color'] ?>
                                <br><strong class="text-decoration-underline text-info">inventory:</strong> <?php echo $vehiclesDataRow['inventory'] ?>
                                <br><strong class="text-decoration-underline text-info">gear:</strong> <?php echo $vehiclesDataRow['gear'] ?>
                                <br><strong class="text-decoration-underline text-info">fuel:</strong> <?php echo $vehiclesDataRow['fuel'] ?>
                                <br><strong class="text-decoration-underline text-info">damage:</strong> <?php echo $vehiclesDataRow['damage'] ?>
                                <br><strong class="text-decoration-underline text-info">insert_time:</strong> <?php echo $vehiclesDataRow['insert_time'] ?>
                            </div>
                        <?php } ?>
                    </div>
                    <br>
                    <br>
                    <h3>Table: Gangs</h3>
                    <?php if (isset($gangsData2['id']) && $gangsData2['owner'] != $pid) { ?>
                        <strong class="text-decoration-underline text-info">id:</strong> <?php echo $gangsData2['id'] ?>
                        <br><strong class="text-decoration-underline text-info">name:</strong> <?php echo $gangsData2['name'] ?>
                        <?php
                            $ownerVAR = $gangsData2['owner'];
                            $playerOwnerSQL = $connectionPDO->prepare("SELECT name FROM players WHERE pid='$ownerVAR'");
                            $playerOwnerSQL->execute();
                            $playerOwner = $playerOwnerSQL->fetch(PDO::FETCH_LAZY);
                        ?>
                        <br><strong class="text-decoration-underline text-info">owner:</strong> <?php echo $playerOwner['name'] ?>
                    <?php }
                        foreach ($gangsData as $gangsDataRow) {
                        $gangBankNumber = $gangsDataRow['bank'];
                        $gangBankFormat = number_format($gangBankNumber, '0', ',', '.');
                    ?>
                        <strong class="text-decoration-underline text-info">id:</strong> <?php echo $gangsDataRow['id'] ?>
                        <br><strong class="text-decoration-underline text-info">owner:</strong> <?php echo $gangsDataRow['owner'] ?>
                        <br><strong class="text-decoration-underline text-info">name:</strong> <?php echo $gangsDataRow['name'] ?>
                        <br><strong class="text-decoration-underline text-info">maxmembers:</strong> <?php echo $gangsDataRow['maxmembers'] ?>
                        <br><strong class="text-decoration-underline text-info">bank:</strong> <span class="text-success">$<?php echo $gangBankFormat ?></span>
                        <br><strong class="text-decoration-underline text-info">active:</strong> <?php echo $gangsDataRow['active'] ?>
                        <br><strong class="text-decoration-underline text-info">insert_time:</strong> <?php echo $gangsDataRow['insert_time'] ?>
                        <div class="d-flex"><strong class="text-decoration-underline text-info">members:</strong><div class="overflow-auto"> <?php echo $gangsDataRow['members'] ?></div></div>
                    <?php }
                        if (isset($gangsData2['id']) && $gangsData2['members'] != '"[`'.$pid.'`]"' && $gangsData2['owner'] == $pid) {
                    ?>   
                    <div class="overflow-auto p-1 w-25 mt-1 border border-1" style="height: 143px !important;">
                        <?php
                            $gangsMembersSTIDSQL = $connectionPDO->prepare("SELECT uid,pid,name FROM players WHERE pid!='$pid' ORDER BY uid ASC");
                            $gangsMembersSTIDSQL->execute();
                            $gangsMembersSTID = $gangsMembersSTIDSQL->fetchAll(PDO::FETCH_ASSOC);
                        ?>
                        <?php foreach ($gangsMembersSTID as $membeSTID) { 
                            $member = $membeSTID['pid'];
                            echo (preg_match("/\b$member\b/", $gangsData2['members'])) ? $membeSTID['uid'].' - '.$membeSTID['name'].'<br>' : "";
                        }} ?>
                    </div>
                    <br>
                    <br>
                    <h3>Table: Wanted</h3>
                    <div class="d-flex gap-3">
                        <?php
                            if ($wantedData == null) {
                                echo "<p>Hasta la fecha no tiene antecedentes penales.</p>";
                            }
                            foreach ($wantedData as $wantedDataRow) {
                                $wantedBountyNumber = $wantedDataRow['wantedBounty'];
                                $wantedBountyFormat = number_format($wantedBountyNumber, '0', ',', '.');
                                $wantedCrimeVariable = $wantedDataRow['wantedCrimes'];
                        ?>
                            <div>
                                <strong class="text-decoration-underline text-info">wantedID:</strong> <?php echo $wantedDataRow['wantedID'] ?>
                                <br><strong class="text-decoration-underline text-info">wantedName:</strong> <?php echo $wantedDataRow['wantedName'] ?>
                                <br><strong class="text-decoration-underline text-info">wantedCrimes:</strong> <?php echo $wantedDataRow['wantedCrimes'] ?>
                                <br><strong class="text-decoration-underline text-info">wantedBounty:</strong> <span class="text-success">$<?php echo $wantedBountyFormat ?></span>
                                <br><strong class="text-decoration-underline text-info">active:</strong> <?php echo $wantedDataRow['active'] ?>
                                <br><strong class="text-decoration-underline text-info">insert_time:</strong> <?php echo $wantedDataRow['insert_time'] ?>
                            </div>
                            <?php if ($wantedCrimeVariable != '[]') { ?>
                                <div class="overflow-auto p-1 border border-1" style="height: 143px !important;">
                                    <p>
                                        <?php
                                            echo (preg_match("/\b1\b/", $wantedCrimeVariable)) ? "[1] Conducir sin Licencia <br>" : "";
                                            echo (preg_match("/\b2\b/", $wantedCrimeVariable)) ? "[2] Conducir en el lado incorrecto de la calle <br>" : "";
                                            echo (preg_match("/\b3\b/", $wantedCrimeVariable)) ? "[3] No respetar las señales <br>" : "";
                                            echo (preg_match("/\b4\b/", $wantedCrimeVariable)) ? "[4] Exceso de Velocidad <br>" : "";
                                            echo (preg_match("/\b5\b/", $wantedCrimeVariable)) ? "[5] Manejar sin luces en la noche <br>" : "";
                                            echo (preg_match("/\b6\b/", $wantedCrimeVariable)) ? "[6] Manejar un Kart sin casco <br>" : "";
                                            echo (preg_match("/\b7\b/", $wantedCrimeVariable)) ? "[7] Vehículo mal estacionado <br>" : "";
                                            echo (preg_match("/\b8\b/", $wantedCrimeVariable)) ? "[8] Vehículo Rebelde (No Armado) <br>" : "";
                                            echo (preg_match("/\b9\b/", $wantedCrimeVariable)) ? "[9] Robo Mayor (Vehículo Civil) <br>" : "";
                                            echo (preg_match("/\b10\b/", $wantedCrimeVariable)) ? "[10] Robo Mayor (Vehículo Militar) <br>" : "";
                                            echo (preg_match("/\b11\b/", $wantedCrimeVariable)) ? "[11] Vehículo Blindado <br>" : "";
                                            echo (preg_match("/\b12\b/", $wantedCrimeVariable)) ? "[12] Volar sobre la ciudad sin autorización <br>" : "";
                                            echo (preg_match("/\b13\b/", $wantedCrimeVariable)) ? "[13] Cerrar las calles sin autorización <br>" : "";
                                            echo (preg_match("/\b14\b/", $wantedCrimeVariable)) ? "[14] Cargar Arma Abiertamente en la Ciudad (Arma Legal) <br>" : "";
                                            echo (preg_match("/\b15\b/", $wantedCrimeVariable)) ? "[15] Arma Rebelde <br>" : "";
                                            echo (preg_match("/\b16\b/", $wantedCrimeVariable)) ? "[16] Ropa Ilegal <br>" : "";
                                            echo (preg_match("/\b17\b/", $wantedCrimeVariable)) ? "[17] Ocultar su Cara (Máscara) <br>" : "";
                                            echo (preg_match("/\b18\b/", $wantedCrimeVariable)) ? "[18] Reusa a Cooperar <br>" : "";
                                            echo (preg_match("/\b19\b/", $wantedCrimeVariable)) ? "[19] Golpea y Corre <br>" : "";
                                            echo (preg_match("/\b20\b/", $wantedCrimeVariable)) ? "[20] Insultar a un Civil <br>" : "";
                                            echo (preg_match("/\b21\b/", $wantedCrimeVariable)) ? "[21] Insultar a un Soldado <br>" : "";
                                            echo (preg_match("/\b22\b/", $wantedCrimeVariable)) ? "[22] Venta de Drogas <br>" : "";
                                            echo (preg_match("/\b23\b/", $wantedCrimeVariable)) ? "[23] Entrar a la Reserva Federal <br>" : "";
                                            echo (preg_match("/\b24\b/", $wantedCrimeVariable)) ? "[24] Homicidio de un Civil <br>" : "";
                                            echo (preg_match("/\b25\b/", $wantedCrimeVariable)) ? "[25] Homicidio de un Soldado <br>" : "";
                                            echo (preg_match("/\b187\b/", $wantedCrimeVariable)) ? "[187] Homicidio <br>" : "";
                                            echo (preg_match("/\b187V\b/", $wantedCrimeVariable)) ? "[187V] Homicidio Vehicular <br>" : "";
                                            echo (preg_match("/\b207\b/", $wantedCrimeVariable)) ? "[207] Secuestro <br>" : "";
                                            echo (preg_match("/\b207A\b/", $wantedCrimeVariable)) ? "[207A] Atentado: Secuestro <br>" : "";
                                            echo (preg_match("/\b211\b/", $wantedCrimeVariable)) ? "[211] Robo <br>" : "";
                                            echo (preg_match("/\b213\b/", $wantedCrimeVariable)) ? "[213] Uso de Explosivos Ilegales <br>" : "";
                                            echo (preg_match("/\b215\b/", $wantedCrimeVariable)) ? "[215] Atentado: Robo de Vehículo <br>" : "";
                                            echo (preg_match("/\b390\b/", $wantedCrimeVariable)) ? "[390] Intoxicación Pública <br>" : "";
                                            echo (preg_match("/\b459\b/", $wantedCrimeVariable)) ? "[459] Robo de Casa <br>" : "";
                                            echo (preg_match("/\b480\b/", $wantedCrimeVariable)) ? "[480] Pega y Corre <br>" : "";
                                            echo (preg_match("/\b481\b/", $wantedCrimeVariable)) ? "[481] Posesión de Drogas <br>" : "";
                                            echo (preg_match("/\b482\b/", $wantedCrimeVariable)) ? "[482] Intención de Distribuir <br>" : "";
                                            echo (preg_match("/\b483\b/", $wantedCrimeVariable)) ? "[483] Tráfico de Drogas <br>" : "";
                                            echo (preg_match("/\b487\b/", $wantedCrimeVariable)) ? "[487] Robo Mayor <br>" : "";
                                            echo (preg_match("/\b488\b/", $wantedCrimeVariable)) ? "[488] Robo Menor <br>" : "";
                                            echo (preg_match("/\b666\b/", $wantedCrimeVariable)) ? "[666] Evadir Impuestos <br>" : "";
                                            echo (preg_match("/\b667\b/", $wantedCrimeVariable)) ? "[667] Terrorismo <br>" : "";
                                            echo (preg_match("/\b668\b/", $wantedCrimeVariable)) ? "[668] Caza sin Licencia <br>" : "";
                                            echo (preg_match("/\b901\b/", $wantedCrimeVariable)) ? "[901] Escaparse de la Cárcel <br>" : "";
                                            echo (preg_match("/\b919\b/", $wantedCrimeVariable)) ? "[919] Robo de Organos <br>" : "";
                                            echo (preg_match("/\b919A\b/", $wantedCrimeVariable)) ? "[919A] Atentado: Robo de Organos <br>" : "";
                                        ?>
                                    </p>
                                </div>
                            <?php } ?>
                        <?php } ?>
                    </div>
                    </div>
            </div>
        </div>
    </div>
</body>
<script src="./libraries/bootstrap/js/bootstrap.min.js"></script>

</html>