<?php
    $loginuser=$_POST['loginuser'];
    $loginpass=$_POST['loginpass'];

    if ($loginuser == "Admin" && $loginpass == "998000") {
        session_start();
        $_SESSION['loginuser']=$loginuser;
        header("location:index");
    } else {
        session_destroy();
        header("location:login");
    }
?>