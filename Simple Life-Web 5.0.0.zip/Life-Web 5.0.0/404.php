<?php
    include "templates/head.html";
?>
<body class="bg-danger">
    <h1 class="display-1 text-center m-auto mt-5">404</h1>
    <p class="text-center">Usted no es un usuario autorizado para operar en esta web.</p>
</body>
</html>